# 后端实测记录（2026-10-31）

最终结果：Maven 3.9.9 `package` 成功，19 项真实 HTTP / MySQL 集成测试全部通过（Failures 0、Errors 0、Skipped 0），测试耗时 17.87 秒，构建总耗时 25.946 秒。完整输出见 `11-final-package.log`，原始 Surefire XML/TXT 见 `green/`。

运行环境：Oracle JDK 17.0.9、Spring Boot 3.3.5、Hibernate 6.5.3.Final、MySQL 8.0.43 / InnoDB、READ-COMMITTED，独立实例 127.0.0.1:13316；专用测试库 course_test。版本原始输出见 `runtime-versions.txt` 与 `database-runtime.txt`。

## 命令

在 backend 目录执行（Maven 3.9 在 PATH 时）：

```powershell
$env:TEST_DB_URL='jdbc:mysql://127.0.0.1:13316/course_test?useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Shanghai'
$env:TEST_DB_USER='course_app'
$env:TEST_DB_PASSWORD='Chapter10Db!'
mvn -s maven-settings.xml -B -ntp package

$env:DB_URL='jdbc:mysql://127.0.0.1:13316/course_demo?useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Shanghai'
$env:DB_USER='course_app'
$env:DB_PASSWORD='Chapter10Db!'
$env:PORT='18080'
java -jar target/course-selection-1.0.0.jar
```

本机 Maven 可执行文件为工作区 `.codex-work/execution-20261031/tools/apache-maven-3.9.9/bin/mvn.cmd`；镜像配置是可选项。隔离测试实例需 TRIGGER 权限；若开启 binlog，管理员设置该实例 `log_bin_trust_function_creators=1`。

## 证据沿革

| 文件 | 实际结果 |
|---|---|
| 00-test-compile.log | 尚未实现业务时测试源代码编译成功；使用本机原有 Maven 3.8.4 预取依赖 |
| 01-red-mysql.log、red/ | 启动骨架在真实 MySQL 上执行 15 项：8 断言失败、7 因预期接口响应尚不存在而出错；V1—V3 迁移成功 |
| 02-red-contract.log | Maven 3.9.9 因仓库标识变化重新校验大量缓存；该运行主动中断，无测试结论 |
| 03-mysql-implementation.log、partial/ | 16 项中 15 项通过；唯一错误是 MySQL 1419 阻止创建测试触发器 |
| 04-trigger-diagnosis.txt | 确认隔离库已授权、binlog=1、trust_function_creators=0；管理员随后仅修正隔离实例 |
| 05-mysql-green.log、green-initial-16/ | 初始 16 项全通过，含回滚故障请求 |
| 06-package.log | 初始 16 项版本打包成功；已被最终含时间窗版本替代 |
| 07-window-http-red.log、window-http-red/ | 新增用例预期失败：尚缺窗口迁移、方法不支持被错误映射成500 |
| 08-mysql-final.log | 新增窗口后的 19 项中 18 项通过；开放时刻用例未取得成功响应 |
| 09-window-timezone-diagnosis.log | 精确复现 SQL 10:00 经 LocalDateTime 映射成 18:00；随后改 Instant 统一存UTC |
| 10-mysql-final-green.log | Instant 修复后 19 项全通过 |
| 11-final-package.log、green/ | 最终 19 项全通过；额外断言选课/退课审计列按固定 Clock 精确存 UTC，JAR 打包成功 |
| 12-missing-password.log | 去除 DB_PASSWORD 后运行最终 JAR，启动退出码1，数据库认证失败；没有静默使用默认数据库密码 |
| 13-final-sql-invariants.txt | 最终测试结束后，新 mysql 客户端连接执行六条只读不变量查询，均无违规结果，退出码0 |

测试不使用 H2、内存业务替身或测试方法外层回滚事务。并发测试从 CountDownLatch 同时释放两条真实 HTTP 请求；回滚注入只由 src/test 临时创建的 MySQL 触发器完成，生产没有故障注入入口。日志中出现的 SQLSTATE 45000 / INTERNAL_ERROR 堆栈属于故意注入的失败，紧随其后的独立数据库断言与同键重试均通过。

## 覆盖

19 个测试方法覆盖认证与固定种子、角色与数据归属、六项功能、重复有效选课、同键重放和异体冲突、退课历史与重新选课、容量/课程/时间/学分约束、恰好学分上限、成绩空值及0/100边界、最多两位小数、CLOSED与评分约束、重复PUT、评分退课并发、不同学生争抢容量1、同学生不同冲突班并发、同键并发、数据库生成列唯一约束、故障回滚及幂等记录原子性、405/415及响应头、窗口开放前/开放时/截止前/截止时、截止后旧键重放与UTC精确存取。

最终 JAR：`target/course-selection-1.0.0.jar`。

SHA256：`4A9ABFF1E3158EB52BE4BB2C8BF4E15ED963AAC86B381575964C32AF4285325D`。
