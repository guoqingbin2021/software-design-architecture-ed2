# 第十章配套工程验收报告

版本：chapter10-v1.0.0。实际执行日期：2026-10-31。结论：六项基本功能、19项真实HTTP/MySQL集成测试、32项前端测试、前后端构建及新目录空库复建均通过。

## 环境

Windows 11、PowerShell7；JDK17.0.9；Maven3.9.9；MySQL8.0.43 / InnoDB；应用事务READ-COMMITTED；Node22.14.0、npm10.9.2；Spring Boot3.3.5、Vue3.5.13、Vite5.4.21。开发与测试数据库隔离。本次数据全部为虚构教学数据。

## 命令和结果

| 检查 | 预期 | 实际 | 原始证据 |
|---|---|---|---|
| Maven clean package | 测试和打包成功 | 19 tests，0 failures，0 errors，0 skipped；BUILD SUCCESS | clean-reproduction/pipeline-maven.log；backend/evidence/green/中的JUnit XML |
| npm ci | 锁文件可安装 | exit0 | clean-reproduction/pipeline-npm-ci.log |
| npm test | 全部通过 | 32 tests，32 pass，0 fail | clean-reproduction/pipeline-npm-test.log |
| npm run build | 生产构建成功 | exit0；15 modules transformed | clean-reproduction/pipeline-npm-build.log |
| 新目录JAR+新空库 | 自动初始化 | Flyway1—5 success=1；6个教学班；班5种子记录ACTIVE且score=NULL | clean-reproduction/clean-backend-start.log、clean-sql.txt |
| 初始API范围 | 学生全部，教师本人 | student1=6、teacher1=4、teacher2=2 | clean-reproduction/clean-http.json |
| 六功能浏览器流程 | 查询→选课→课表→退课→名单→评分 | 均取得预期页面与持久化结果 | 01—05截图、browser-snapshots/ |
| 操作后独立核对 | 退课历史保留，成绩85，越权403 | 全部符合 | browser-api-checks.json、browser-final-database.txt |
| 六项SQL不变量 | 违规行数均为0 | 均为0，客户端exit0 | browser-invariants.txt，scripts/verify-invariants.sql |

顶层 `pipeline-*.log` 是最终干净目录复建日志的副本。完整原始路径以表中为准；日志中的教学密码仅为本包固定样例，不含个人凭据。

## 后端测试覆盖

测试通过真实HTTP调用Spring服务，使用真实MySQL；测试方法没有外层回滚事务。并发由栅栏协调独立请求，完成后从独立数据库连接断言。

- 容量1的两个学生竞争：一条成功、一条拒绝，人数与ACTIVE计数均为1，无超选。
- 同学生冲突班竞争、重复课程、时间冲突、学分与恰好上限；同键并发与同键不同目标。
- 选课、重复选课、退课、重复退课、退后新选、旧键重放；生成列唯一约束与历史保留。
- 在Enrollment和人数flush后、幂等快照INSERT时由测试临时触发器抛错；事务结束后人数、记录、请求表均回滚，同键可重试。触发器finally清理，生产没有故障入口。
- 401、403、归属与任课关系；成绩0/100/非法值/空值/精度、CLOSED限制、重复PUT及评分退课并发。
- 开放前、恰好开放、截止前、恰好截止、截止后旧键重放；固定Clock及UTC审计列；405/415错误映射。

具体测试方法与每项结果见后端JUnit XML、`backend/evidence/RUNS.md`及需求追踪表。前端32项验证协议、乱序响应、超时未知状态、身份切换、重试幂等与页面规则；前端单元测试不替代真实数据库测试，六功能另有浏览器记录。

## 浏览器实测

Chrome无头浏览器连接实际Vite15173与Spring18080。student1选择班1后课表显示周一第1–2节；退课后当前课表为空，数据库保留WITHDRAWN记录且班1人数0。teacher2打开班5名单并给student3录入85，刷新及新SQL连接均为85。teacher1和学生直接请求班5名单均403。

截图中的工具栏来自浏览器测试记录器。控制台仅有一次未提供favicon.ico的404，没有业务请求失败或JavaScript异常；此项不影响六项功能。页面“选课成功”与“退课成功”分别保留最近操作提示，当前状态以课表与数据库为准。

## 失败记录与修复

后端和前端evidence保留开发期红灯结果，不能把这些旧失败与最终通过混淆。后端修复了未实现接口、测试触发器权限配置、405/415映射及时间窗口时区问题；前端修复了查询乱序、退出迟到响应、未知写入结果、状态枚举及旧快照误提示。

首次整体验收在演示JAR仍运行时执行Maven clean，Windows拒绝删除JAR；原失败日志保存在development/pipeline-maven.log。README与教材已改为“先verify，再启动”，并在新目录实际重走成功。最后独立审查将脚本入口统一为实测的PowerShell7（pwsh），避免Windows PowerShell5.1对原生stderr的不同处理；工程不声称支持5.1。

## 范围

本报告证明固定教学数据与上述功能/约束的执行结果，不构成高并发性能或生产安全认证。候补、可靠通知、微服务拆分、在线教务排课是明确列出的选做，基本版未实现。第三方真人课堂验收及教师签字留空；已完成的同机干净目录空库复建见RESULT.json。
