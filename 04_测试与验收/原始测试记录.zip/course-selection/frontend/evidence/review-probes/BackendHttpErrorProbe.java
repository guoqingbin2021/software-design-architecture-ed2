import edu.textbook.selection.api.ApiExceptionHandler;
import edu.textbook.selection.api.CourseSelectionController;
import edu.textbook.selection.api.RequestIdFilter;
import edu.textbook.selection.service.EnrollmentService;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.security.web.method.annotation.AuthenticationPrincipalArgumentResolver;
import java.nio.charset.StandardCharsets;
import static org.mockito.Mockito.mock;

/** Read-only review probe: no Spring application or database connection is started. */
public class BackendHttpErrorProbe {
    public static void main(String[] args) throws Exception {
        MockMvc mvc = MockMvcBuilders.standaloneSetup(new CourseSelectionController(mock(EnrollmentService.class)))
                .setControllerAdvice(new ApiExceptionHandler()).setCustomArgumentResolvers(new AuthenticationPrincipalArgumentResolver())
                .addFilters(new RequestIdFilter()).build();
        var method = mvc.perform(MockMvcRequestBuilders.post("/api/me").contentType(MediaType.APPLICATION_JSON).content("{}"))
                .andReturn().getResponse();
        var media = mvc.perform(MockMvcRequestBuilders.put("/api/enrollments/1/score").contentType(MediaType.TEXT_PLAIN).content("85"))
                .andReturn().getResponse();
        var invalidJson = mvc.perform(MockMvcRequestBuilders.put("/api/enrollments/1/score").contentType(MediaType.APPLICATION_JSON).content("{"))
                .andReturn().getResponse();
        System.out.println("PROBE method POST /api/me => " + method.getStatus() + " " + method.getContentAsString(StandardCharsets.UTF_8));
        System.out.println("PROBE media text/plain => " + media.getStatus() + " " + media.getContentAsString(StandardCharsets.UTF_8));
        System.out.println("PROBE malformed JSON => " + invalidJson.getStatus() + " " + invalidJson.getContentAsString(StandardCharsets.UTF_8));
        System.out.println("PROBE Allow => " + method.getHeader("Allow") + "; Accept => " + media.getHeader("Accept"));
        if(method.getStatus() != 405 || media.getStatus() != 415 || invalidJson.getStatus() != 400)
            throw new AssertionError("HTTP client errors should retain 405/415/400 instead of becoming INTERNAL_ERROR");
        if(method.getHeader("Allow") == null || !method.getHeader("Allow").contains("GET") || media.getHeader("Accept") == null || !media.getHeader("Accept").contains("application/json"))
            throw new AssertionError("405 and 415 should preserve supported method and media type headers");
    }
}
