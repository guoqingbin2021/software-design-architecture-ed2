# 前端验证记录

日期：2026-10-31（Asia/Shanghai）。范围为本目录的前端逻辑、依赖安装与生产构建；真实 MySQL 和浏览器全流程验收由总工程报告记录。

## 实测基线

| 项目 | 实测版本 |
|---|---|
| Node.js | 22.14.0 |
| npm | 10.9.2 |
| Vue | 3.5.13 |
| Vite | 5.4.21 |
| @vitejs/plugin-vue | 5.2.4 |

`versions.log` 包含实际命令输出。使用以下 portable 运行时，并将其目录置于进程 PATH 首位，使 npm 脚本中的 `node` 使用同一个版本：

```powershell
$taskNodeDir = 'C:\Users\guoqi\Desktop\工作量\教材2\.codex-work\execution-20261031\tools\node-v22.14.0-win-x64'
$taskNode = Join-Path $taskNodeDir 'node.exe'
$taskNpm = Join-Path $taskNodeDir 'node_modules\npm\bin\npm-cli.js'
$env:PATH = "$taskNodeDir;" + $env:PATH
# 工作目录：配套工程/course-selection/frontend
& $taskNode $taskNpm ci --no-audit --no-fund
& $taskNode $taskNpm test
& $taskNode $taskNpm run build
```

## 结果

| 检查 | 实际结果 | 原始日志 |
|---|---|---|
| 干净安装 `npm ci` | exit 0；added 31 packages | `npm-ci.log` |
| `npm test` | exit 0；32 tests、32 pass、0 fail | `npm-test.log` |
| `npm run build` | exit 0；15 modules transformed | `npm-build.log` |
| 本地开发服务 | Node 22.14.0 进程监听 15173；GET `/` 为 HTTP 200，标题匹配 | 总工程浏览器验收另行记录 |

最终生产构建：`dist/index.html` 0.45 kB、CSS 7.75 kB、JS 87.21 kB；gzip 分别为 0.35、2.44、33.87 kB。文件名带内容哈希，后续任何源文件变更应重新运行构建，以新日志为准。

## 自动化覆盖

- 请求发送 Basic 身份、JSON 与原幂等键；接口路径、204、统一业务错误和退出后的身份清除。
- 网络中断、5xx、超时以及响应体阶段超时的写请求进入 `uncertain`；GET 超时保持为查询错误。
- 同一资源查询乱序、迟到错误、教师快速切班、退出后的迟到响应、首屏查询期间退出。
- 选课防重复点击；未知结果保留原幂等键；普通点击只查询确认；显式重试先查询并沿用原键。
- 查询确认失败不视为写入失败；刷新恢复待确认选课；明确业务拒绝结束待确认状态。
- 退课和成绩通过查询确认；退课未知时禁止新选课；成绩范围与空值校验。
- 学生和教师初始查询分流；课表仅显示有效选课并按星期和节次排序。
- 使用后端实际 ACTIVE/WITHDRAWN 枚举；OPEN 未评分有效记录可退，CLOSED 本班有效记录可录成绩，拒绝超过两位小数的成绩。
- 旧幂等键回放历史成功、但当前 ACTIVE 查询中已无该班时，不把历史快照宣称为当前选课成功。

测试使用 Node 内置测试器。API 通过可控 `fetchImpl` 注入验证协议及超时，状态控制器通过可控 Promise 验证真实异步状态变更；这部分测试不声称替代浏览器或真实后端数据库验证。

## 测试先行记录

`store-red.log`、`api-red.log`、`presenters-red.log` 保存相应实现前的失败结果；`response-body-timeout-red.log`、`login-logout-race-red.log`、`drop-enroll-lock-red.log` 保存发现并修复边界缺陷前的失败结果。早期开发红灯记录曾使用 bundled Node 24.19.0；最终 `npm-ci.log`、`npm-test.log`、`npm-build.log`、`versions.log` 均已统一重新运行于 Node 22.14.0。

`backend-contract-red.log`、`class-lifecycle-red.log`、`replay-snapshot-message-red.log` 保存对照后端实际契约后先补测试、再修复前端的红灯结果。只读后端审查与无数据库复现见 `BACKEND-CONTRACT-REVIEW.md`。

最终交付保留源代码、锁文件、文档、测试及这些实测日志；`node_modules/` 不进入交付压缩包。
