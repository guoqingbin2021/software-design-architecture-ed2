# 后端与前端契约独立审查

日期：2026-10-31。逐文件阅读后端 `src/main`、`src/test`、迁移、配置与 README，并与前端 App、API、store、展示函数及说明对照。本次没有修改后端实现，没有占用浏览器，没有运行会清理 `course_test` 的集成测试；实际复现使用无数据库的独立 MockMvc 探针。后端 Clock 与 HTTP 错误补丁由后端任务实施；审查已读取其修复后的源码、实际 Surefire XML 和构建日志，HTTP 错误另用本探针独立复核。

## 行动项

| 优先级 | 发现与影响 | 状态 |
|---|---|---|
| P1 | 前端误用 ENROLLED/DROPPED，而后端为 ACTIVE/WITHDRAWN，导致有效课表、已选判断、退课/成绩按钮和超时确认错误。 | 已修复前端并同步测试、文档；Node22 全套 32/32 通过。 |
| P2 | 前端没有按 CLOSED 限制录成绩、按 OPEN 与未评分限制退课，且未校验最多两位小数。服务端会拒绝，但页面提供了不能成功的操作。 | 已修复，新增 class-lifecycle 回归测试。 |
| P2 | 前端承诺展示退课历史，但 GET `/api/enrollments/me` 实际仅返回 ACTIVE。 | 经主任务决定保持接口语义，页面改为当前有效选课，注明历史留在数据库供审计。 |
| P2 | 旧键回放返回原成功快照，其选课可能已被另一标签页退掉；前端原先只凭 POST 200 显示“选课成功”。 | 已修复为 POST 后查询当前记录；不在 ACTIVE 列表中则明确提示当前未包含该班，不产生新键或自动新请求。 |
| P2 | `ApiExceptionHandler` 的泛化 Exception 处理将不支持的方法与 Content-Type 映射成 500，错误地把客户端错误归为服务端故障。写请求还会因此被前端标为 uncertain。 | 后端已修复；独立无数据库探针实际验证 405/415/400、Allow 与 Accept，exit 0，保留前后日志。 |
| P1 | 新增窗口测试发现 SQL UTC 字面量 10:00 通过原 LocalDateTime 映射读成 18:00，导致开放边界偏移 8 小时。 | 后端将窗口及审计时间改为 Instant、服务使用 clock.instant()；已逐读修复代码及实际窗口用例通过结果。 |

HTTP 复现结果：`POST /api/me` 为 **500 INTERNAL_ERROR**，`PUT /api/enrollments/1/score` 且 `Content-Type: text/plain` 为 **500 INTERNAL_ERROR**；格式错误 JSON 对照为 **400 VALIDATION_ERROR**。建议分别保留 **405 METHOD_NOT_ALLOWED**（含 Allow）与 **415 UNSUPPORTED_MEDIA_TYPE**，保持 `{code,message,requestId}` 结构，并补真实 HTTP 集成断言。相关源位置为后端 `api/ApiExceptionHandler.java` 泛化异常处理。

修复后独立复跑同一探针，结果为 **405 METHOD_NOT_ALLOWED**、**415 UNSUPPORTED_MEDIA_TYPE**、**400 VALIDATION_ERROR**，`Allow=GET`、`Accept=application/json, application/*+json`，全部断言通过，exit 0。见 `review-probes/http-errors-after.log`。

## 已核对的实现

- 六项功能均有 Controller、Service、Repository 及 DTO 对应：教学班查询、选课、退课、本人课表、本班名单、成绩录入。
- 选课、退课、成绩都在 READ_COMMITTED 写事务中，按学生行再教学班行取悲观锁；退课/成绩先查不可变坐标，取得锁后再加载可变 Enrollment，避免锁前缓存旧实体。
- 同学生不同班的请求由学生锁串行；不同学生争名额由教学班锁保护。容量、重复课程、时间冲突、学分、持久化、人数与请求记录均在事务内。
- Enrollment 的 ACTIVE/WITHDRAWN 状态及生成列唯一约束保留历史并约束有效关系。EnrollmentRequest 独立保存原响应快照；旧键回放先于当前班级状态与业务校验，不复活历史关系；同键异班拒绝。
- 角色取自认证 principal；学生退课核对本人、教师名单和评分核对任课教师；教师教学班列表按本人过滤。未发现由请求体传入学生 ID 绕过归属的路径。
- 教师评分要求 CLOSED 且 ACTIVE，范围 0–100、最多两位小数；已评分/关闭班级的有效选课不能退课。重复退课保持幂等。
- DTO 的 ID 为 JSON 数值，成绩与学分为 BigDecimal 数值，当前样例 ID 在 JavaScript 精确整数范围内；前端对输入成绩转 Number 后校验，小数成绩确认也按数值比较。Jackson 已拒绝未知字段和浮点转整数 ID。
- V5 窗口采用 `[open_at, close_at)`；生产 Clock 为 UTC，持锁后采样 Instant。原请求先回放，不被新窗口截止破坏；退课先识别已退课状态，重复退课不重新扣人数。新测试使用真实 HTTP、可控 Clock 和 SQL UTC 字面量核对开放时刻、截止前一微秒、截止时刻及旧键回放。

## 测试盲点与范围

原前端单元测试使用了错误枚举，说明单侧可控 API fixture 无法替代真实契约验证；现已按实际 DTO 修正，并由主任务运行真实浏览器联调。原后端集成测试没有 405/415，已将此真实缺陷反馈后端。历史幂等与当前 UI 状态的差异原先未覆盖，现已补前端回归测试。

本次未亲自重跑后端全量 MySQL 测试，避免与后端任务正在维护的专用测试库并行冲突；已实际读取修复后的 Surefire XML：19 tests、0 failures、0 errors、0 skipped，窗口和 HTTP 错误两个用例均无 failure；`backend/evidence/10-mysql-final-green.log` 记录 2026-10-31 22:56:12 的 BUILD SUCCESS。后端随后新增 enrolled_at/withdrawn_at 的原始 SQL UTC 存储断言并进行最终 package 回归，应以其最终报告为准。静态审查和独立 MockMvc 复现没有发现锁顺序、授权或事务回放机制的其他阻断缺陷。

## 无数据库探针复现

`review-probes/BackendHttpErrorProbe.java` 直接组合实际 Controller、Advice、RequestIdFilter 和 AuthenticationPrincipal 参数解析器；Service 使用 Mockito mock，没有启动 SpringBoot 应用、没有连接数据库。使用现有 Surefire 的测试 classpath，无需改后端文件或增加依赖：

```powershell
$backendRoot = '..\backend' # 从 frontend 目录运行
[xml]$report = Get-Content -Raw "$backendRoot\target\surefire-reports\TEST-edu.textbook.selection.CourseSelectionIntegrationTest.xml"
$probeClasspath = ($report.testsuite.properties.property | Where-Object { $_.name -eq 'java.class.path' }).value
java '-Dfile.encoding=UTF-8' --class-path $probeClasspath evidence/review-probes/BackendHttpErrorProbe.java
```

修复前退出码为 1，原始日志为 `review-probes/http-errors-before.log`；修复后退出码为 0，原始日志为 `review-probes/http-errors-after.log`。后端后续变更时可用同一探针重新验证 405/415/400。
